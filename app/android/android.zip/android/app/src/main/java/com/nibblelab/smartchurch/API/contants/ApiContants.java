package com.nibblelab.smartchurch.API.contants;

public class ApiContants {
    public static final String BASE_URL = "https://www.smartchurch.software/api/";
    public static final String RC_URL = "https://www.smartchurch.software/api/rc";
    public static final String IBGE_URL = "https://servicodados.ibge.gov.br/api/v1/";
}
