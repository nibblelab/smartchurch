package com.nibblelab.smartchurch.API;

import com.nibblelab.smartchurch.activity.Base;

public class BaseAPI {

    protected String token;
    protected Base b;

    public BaseAPI(final Base b) {
        this.b = b;
    }

    public String getAuthToken() {
        return "token=" + b.getUserTokenValue();
    }

}
