package com.nibblelab.smartchurch.ui.events;

public interface SermaoListEvents {
    void onSelectSermao(Object object);
}
