package com.nibblelab.smartchurch.model;

import com.google.gson.annotations.SerializedName;

public class UFData {

    @SerializedName("id")
    private int id;
    @SerializedName("sigla")
    private String sigla;
    @SerializedName("nome")
    private String nome;

    public UFData() {
    }

    public UFData(int id, String sigla, String nome) {
        this.id = id;
        this.sigla = sigla;
        this.nome = nome;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getSigla() {
        return sigla;
    }

    public void setSigla(String sigla) {
        this.sigla = sigla;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }
}
