package com.nibblelab.smartchurch.activity;

import android.content.DialogInterface;
import android.os.Bundle;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.widget.ProgressBar;

import com.nibblelab.smartchurch.R;
import com.nibblelab.smartchurch.common.DialogHelper;
import com.nibblelab.smartchurch.model.TokenData;
import com.nibblelab.smartchurch.model.UserData;
import com.nibblelab.smartchurch.storage.TokenStorage;
import com.nibblelab.smartchurch.storage.UserStorage;

import java.io.FileNotFoundException;
import java.io.IOException;

public class Base extends AppCompatActivity {

    protected ProgressBar progress;
    protected TokenData token;
    protected UserData user;

    public static final String TAG = "Base";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        this.getUserToken();
        this.getUserData();
    }

    public void setUserToken(String t)
    {
        TokenData token = new TokenData();
        token.setToken(t);
        TokenStorage st = new TokenStorage(this, getString(R.string.token_file));
        try {
            st.write(token);
        } catch (IOException e) {
            Log.d(TAG, e.getMessage());
        }
    }

    public void getUserToken()
    {
        TokenStorage st = new TokenStorage(this, getString(R.string.token_file));
        try {
            token = st.read();
        } catch (FileNotFoundException e) {
            Log.d(TAG, e.getMessage());
        } catch (IOException e) {
            Log.d(TAG, e.getMessage());
        }
    }

    public String getUserTokenValue()
    {
        this.getUserToken();
        return token.getToken();
    }

    public boolean isUserLogged()
    {
        return (this.token != null && !this.token.getToken().equals(""));
    }

    public void getUserData()
    {
        UserStorage st = new UserStorage(this, getString(R.string.user_file));
        try {
            user = st.read();
        } catch (FileNotFoundException e) {
            Log.d(TAG, e.getMessage());
        } catch (IOException e) {
            Log.d(TAG, e.getMessage());
        }
    }

    public UserData getUser()
    {
        return this.user;
    }

    public boolean userHasPermission(String perm)
    {
        if(user == null) {
            this.getUserData();
        }

        return UserData.doIHavePermission(user.getPerms(), perm);
    }

    public void errDialog(String title, String msg, final DialogHelper r)
    {
        AlertDialog alertDialog = new AlertDialog.Builder(this, R.style.AppTheme_DialogDanger).create();
        alertDialog.setTitle(title);
        alertDialog.setMessage(msg);
        alertDialog.setButton(AlertDialog.BUTTON_POSITIVE, "Ok",
                new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int which) {
                        dialog.dismiss();
                        r.onOk();
                    }
                });
        alertDialog.show();
    }

    public void errDialog(String title, String msg)
    {
        this.errDialog(title, msg, new DialogHelper() {
            @Override
            public void onCancel() {

            }

            @Override
            public void onOk() {

            }
        });
    }

    public void warningDialog(String title, String msg, final DialogHelper r)
    {
        AlertDialog alertDialog = new AlertDialog.Builder(this, R.style.AppTheme_DialogWarning).create();
        alertDialog.setTitle(title);
        alertDialog.setMessage(msg);
        alertDialog.setButton(AlertDialog.BUTTON_POSITIVE, "Ok",
                new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int which) {
                        dialog.dismiss();
                        r.onOk();
                    }
                });
        alertDialog.show();
    }

    public void warningDialog(String title, String msg)
    {
        this.warningDialog(title, msg, new DialogHelper() {
            @Override
            public void onCancel() {

            }

            @Override
            public void onOk() {

            }
        });
    }

    public void infoDialog(String title, String msg, final DialogHelper r)
    {
        AlertDialog alertDialog = new AlertDialog.Builder(this, R.style.AppTheme_DialogInfo).create();
        alertDialog.setTitle(title);
        alertDialog.setMessage(msg);
        alertDialog.setButton(AlertDialog.BUTTON_POSITIVE, "Ok",
                new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int which) {
                        dialog.dismiss();
                        r.onOk();
                    }
                });
        alertDialog.show();
    }

    public void infoDialog(String title, String msg)
    {
        this.infoDialog(title, msg, new DialogHelper() {
            @Override
            public void onCancel() {

            }

            @Override
            public void onOk() {

            }
        });
    }

    public void successDialog(String title, String msg, final DialogHelper r)
    {
        AlertDialog alertDialog = new AlertDialog.Builder(this, R.style.AppTheme_DialogSuccess).create();
        alertDialog.setTitle(title);
        alertDialog.setMessage(msg);
        alertDialog.setButton(AlertDialog.BUTTON_POSITIVE, "Ok",
                new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int which) {
                        dialog.dismiss();
                        r.onOk();
                    }
                });
        alertDialog.show();
    }

    public void successDialog(String title, String msg)
    {
        this.successDialog(title, msg, new DialogHelper() {
            @Override
            public void onCancel() {

            }

            @Override
            public void onOk() {

            }
        });
    }

    public void initLoadingSpinner()
    {
        if(progress == null)
            return;
        progress.setVisibility(View.GONE);
    }

    public void showLoadingSpinner()
    {
        progress.setVisibility(View.VISIBLE);
    }

    public void hideLoadingSpinner()
    {
        progress.setVisibility(View.GONE);
    }

    public void doLogout() {}
}
