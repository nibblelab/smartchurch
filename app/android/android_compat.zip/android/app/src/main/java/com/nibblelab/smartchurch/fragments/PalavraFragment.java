package com.nibblelab.smartchurch.fragments;

import android.content.Context;
import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.support.design.widget.FloatingActionButton;
import android.support.v7.widget.AppCompatSpinner;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.text.Html;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.nibblelab.smartchurch.API.SerieSermaoAPI;
import com.nibblelab.smartchurch.API.SermaoAPI;
import com.nibblelab.smartchurch.API.responses.ApiResponse;
import com.nibblelab.smartchurch.R;
import com.nibblelab.smartchurch.adapters.SermaoAdapter;
import com.nibblelab.smartchurch.common.StringHelper;
import com.nibblelab.smartchurch.model.SerieSermaoData;
import com.nibblelab.smartchurch.model.SermaoData;
import com.nibblelab.smartchurch.ui.events.SermaoListEvents;

import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;


public class PalavraFragment extends BaseFragment implements SermaoListEvents{

    private static final String TAG = "PalavraFragment";
    private OnPalavraFragInteractionListener mListener;

    //inputs
    AppCompatSpinner serie;

    // dados
    List<SerieSermaoData> series;

    // adapters (spinners)
    ArrayAdapter<String> serieSermaoDataAdapter;

    // id's
    String id_serie;
    String igreja;

    // lista de sermões
    RecyclerView sermoesView;
    RecyclerView.LayoutManager sermoesLayoutManager;
    SermaoAdapter sermaoAdapter;
    List<SermaoData> sermoes;

    // sermão
    SermaoData sermao;
    TextView sermaoTitulo;
    TextView sermaoTexto;

    // controles
    LinearLayout sermoesListWrp;
    RelativeLayout sermaoDataWrp;
    FloatingActionButton sermaoBack;
    Button sermaoListPrev;
    Button sermaoListNext;
    int page = 1;
    int pageSize = 5;

    public PalavraFragment() {
        // Required empty public constructor
    }

    public static PalavraFragment newInstance() {
        PalavraFragment fragment = new PalavraFragment();
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {

        }
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View inf = inflater.inflate(R.layout.fragment_palavra, container, false);

        igreja = activity.getUser().getMembresia().getIgreja();
        id_serie = "";

        // inputs
        serie = (AppCompatSpinner) inf.findViewById(R.id.serie_spinner);

        // views
        sermoesView = (RecyclerView) inf.findViewById(R.id.sermoes_list);
        sermoesListWrp = (LinearLayout) inf.findViewById(R.id.include_sermoes);
        sermaoDataWrp = (RelativeLayout) inf.findViewById(R.id.include_sermao);

        // sermão
        sermaoTitulo = (TextView) inf.findViewById(R.id.sermao_dt_titulo);
        sermaoTexto = (TextView) inf.findViewById(R.id.sermao_dt_texto);

        // controles
        sermaoBack = (FloatingActionButton) inf.findViewById(R.id.pv_back);
        sermaoListPrev = (Button) inf.findViewById(R.id.sermoes_anterior);
        sermaoListNext = (Button) inf.findViewById(R.id.sermoes_proximo);

        sermaoListPrev.setVisibility(View.GONE);
        sermaoListNext.setVisibility(View.GONE);

        sermaoBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                toSermoesList();
            }
        });

        sermaoListPrev.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                toPrevPage();
            }
        });

        sermaoListNext.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                toNextPage();
            }
        });

        this.toggleListArea(true);
        this.getSeriesSermoes();
        this.getSermoes();

        return inf;
    }

    public void toggleListArea(boolean show)
    {
        if(show) {
            sermoesListWrp.setVisibility(View.VISIBLE);
            sermaoDataWrp.setVisibility(View.GONE);
        }
        else {
            sermoesListWrp.setVisibility(View.GONE);
            sermaoDataWrp.setVisibility(View.VISIBLE);
        }
    }

    public void getSeriesSermoes()
    {
        activity.showLoadingSpinner();
        SerieSermaoAPI api = new SerieSermaoAPI(activity);
        api.getSeriesSermaoAtivos(igreja, new ApiResponse<List<SerieSermaoData>>() {
            @Override
            public void onResponse() {
                activity.hideLoadingSpinner();
            }

            @Override
            public void onResponse(List<SerieSermaoData> data) {
                activity.hideLoadingSpinner();
                PalavraFragment.this.generateSerieSermoesSpinner(data);
            }

            @Override
            public void onResponse(List<SerieSermaoData> data, int total) {
                activity.hideLoadingSpinner();
            }

            @Override
            public void onAlreadyExecuted() { }

            @Override
            public void onError(String msg) {
                activity.hideLoadingSpinner();
                Log.d(TAG, "Erro: " + msg);
            }

            @Override
            public void onFail(Object fail) {
                activity.hideLoadingSpinner();
                Log.d(TAG, "falha");
            }
        });
    }

    public void generateSerieSermoesSpinner(List<SerieSermaoData> datas)
    {
        series = datas;
        List<String> lista = new ArrayList<String>();
        int indx = -1;
        int counter = 1;

        lista.add("Filtrar por Série");
        for(SerieSermaoData i : series)
        {
            lista.add(i.getNome());
            if(StringHelper.notEmpty(id_serie) && id_serie.equals(i.getId())) {
                indx = counter;
            }
            counter++;
        }

        serieSermaoDataAdapter = new ArrayAdapter<String>(getActivity(),
                android.R.layout.simple_spinner_item, lista);
        serieSermaoDataAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        serie.setAdapter(serieSermaoDataAdapter);

        serie.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                String nome = parent.getItemAtPosition(position).toString();
                String serie_selected = SerieSermaoData.getIdByNomeOnList(series, nome);
                if(StringHelper.notEmpty(serie_selected)) {
                    id_serie = serie_selected;
                }
                else {
                    id_serie = "";
                }
                getSermoes();
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });
    }

    public void getSermoes()
    {
        activity.showLoadingSpinner();
        SermaoAPI api = new SermaoAPI(activity);
        api.getSermoesAtivosOfSerieByPage(igreja, id_serie, page, pageSize, new ApiResponse<List<SermaoData>>() {
            @Override
            public void onResponse() {
                activity.hideLoadingSpinner();
            }

            @Override
            public void onResponse(List<SermaoData> data) {
                activity.hideLoadingSpinner();
            }

            @Override
            public void onResponse(List<SermaoData> data, int total) {
                activity.hideLoadingSpinner();
                PalavraFragment.this.generateSermoes(data, total);
            }

            @Override
            public void onAlreadyExecuted() { }

            @Override
            public void onError(String msg) {
                activity.hideLoadingSpinner();
                Log.d(TAG, "Erro: " + msg);
            }

            @Override
            public void onFail(Object fail) {
                activity.hideLoadingSpinner();
                Log.d(TAG, "falha");
            }
        });
    }

    private boolean hasNextPage(int max)
    {
        int current = page * pageSize;
        return (current < max);
    }

    public void toNextPage()
    {
        page++;
        this.getSermoes();
    }

    public void toPrevPage()
    {
        page--;
        this.getSermoes();
    }

    public void generateSermoes(List<SermaoData> datas, int total)
    {
        sermoes = datas;
        sermoesLayoutManager = new LinearLayoutManager(this.getContext());
        sermoesView.setLayoutManager(sermoesLayoutManager);

        sermaoAdapter = new SermaoAdapter(this.getContext(), sermoes,this);
        sermoesView.setAdapter(sermaoAdapter);

        // veja se é possível exibir o botão de página anterior
        if(page == 1) {
            sermaoListPrev.setVisibility(View.GONE);
        }
        else {
            sermaoListPrev.setVisibility(View.VISIBLE);
        }

        // veja se é possível exibir o botão de próxima página
        if(hasNextPage(total)) {
            sermaoListNext.setVisibility(View.VISIBLE);
        }
        else {
            sermaoListNext.setVisibility(View.GONE);
        }
    }

    @Override
    public void onSelectSermao(Object object)
    {
        sermao = (SermaoData) object;
        sermaoTitulo.setText(sermao.getTitulo());
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
            sermaoTexto.setText(Html.fromHtml(sermao.getConteudo(), Html.FROM_HTML_MODE_COMPACT));
        }
        else {
            sermaoTexto.setText(Html.fromHtml(sermao.getConteudo()));
        }

        // veja se tem vídeo e em caso afirmativo, teste se é youtube ou vimeo
        if(StringHelper.notEmpty(sermao.getVideo())) {
            if(sermao.getVideo().contains("vimeo")) {
                // vimeo
            }
            else if(sermao.getVideo().contains("youtube")) {
                // youtube
                Pattern pattern = Pattern.compile("/youtube\\.com\\/watch\\?v=([\\da-zA-Z_\\-]*)/i");
                Matcher matcher = pattern.matcher(sermao.getVideo());

            }
            else if(sermao.getVideo().contains("youtu.be")) {
                // youtube reduzido
            }

        }

        this.toggleListArea(false);
    }

    public void clearSermaoData()
    {
        sermaoTitulo.setText("");
        sermaoTexto.setText("");
    }

    public void toSermoesList()
    {
        this.toggleListArea(true);
        this.clearSermaoData();
    }

    public void onButtonPressed() {
        if (mListener != null) {
            mListener.onPalavraFragmentInteraction();
        }
    }

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
        if (context instanceof OnPalavraFragInteractionListener) {
            mListener = (OnPalavraFragInteractionListener) context;
        } else {
            throw new RuntimeException(context.toString()
                    + " must implement OnFragmentInteractionListener");
        }
    }

    @Override
    public void onDetach() {
        super.onDetach();
        mListener = null;
    }

    public interface OnPalavraFragInteractionListener {
        void onPalavraFragmentInteraction();
    }
}
