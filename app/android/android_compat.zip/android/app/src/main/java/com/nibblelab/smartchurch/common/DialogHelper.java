package com.nibblelab.smartchurch.common;

public interface DialogHelper {
    public void onCancel();
    public void onOk();
}
