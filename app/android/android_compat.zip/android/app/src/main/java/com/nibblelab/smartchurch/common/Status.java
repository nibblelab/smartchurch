package com.nibblelab.smartchurch.common;

public class Status {
    public static final String ATIVO = "ATV";
    public static final String NAO_ATIVO = "BLK";
}
