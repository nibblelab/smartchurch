package com.nibblelab.smartchurch.activity;

import android.content.Intent;
import android.net.Uri;
import android.support.design.widget.NavigationView;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentTransaction;
import android.support.v4.view.GravityCompat;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.ActionBarDrawerToggle;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.ProgressBar;
import android.widget.TextView;

import com.nibblelab.smartchurch.R;
import com.nibblelab.smartchurch.fragments.HomeFragment;
import com.nibblelab.smartchurch.fragments.MembresiaFragment;
import com.nibblelab.smartchurch.fragments.PalavraFragment;
import com.nibblelab.smartchurch.fragments.PerfilFragment;

public class SmartChurch extends Base
        implements NavigationView.OnNavigationItemSelectedListener,
                    HomeFragment.OnHomeFragInteractionListener,
                    PerfilFragment.OnPerfilFragInteractionListener,
                    MembresiaFragment.OnMembresiaFraInteractionListener,
                    PalavraFragment.OnPalavraFragInteractionListener {

    public static final String TAG = "SmartChurch";

    NavigationView navigationView;
    TextView nome;
    TextView email;
    Menu menu;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_smartchurch);
        Toolbar toolbar = findViewById(R.id.toolbar);

        DrawerLayout drawer = findViewById(R.id.drawer_layout);
        navigationView = findViewById(R.id.nav_view);
        ActionBarDrawerToggle toggle = new ActionBarDrawerToggle(
                this, drawer, toolbar, R.string.navigation_drawer_open, R.string.navigation_drawer_close);
        drawer.addDrawerListener(toggle);
        toggle.syncState();
        navigationView.setNavigationItemSelectedListener(this);

        progress = (ProgressBar) findViewById(R.id.loading);
        this.initLoadingSpinner();

        this.generateHeaderData();
        this.toInicio(false);

        menu = navigationView.getMenu();
    }

    private void generateHeaderData()
    {
        View headerLayout = navigationView.getHeaderView(0);
        nome = (TextView) headerLayout.findViewById(R.id.menu_nome);
        email = (TextView) headerLayout.findViewById(R.id.menu_email);

        if(this.isUserLogged())
        {
            nome.setText(this.user.getNome());
            email.setText(this.user.getEmail());
        }
    }

    @Override
    public void onBackPressed() {
        DrawerLayout drawer = findViewById(R.id.drawer_layout);
        if (drawer.isDrawerOpen(GravityCompat.START)) {
            drawer.closeDrawer(GravityCompat.START);
        } else {
            super.onBackPressed();
        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_content, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        return super.onOptionsItemSelected(item);
    }

    @SuppressWarnings("StatementWithEmptyBody")
    @Override
    public boolean onNavigationItemSelected(MenuItem item) {

        int id = item.getItemId();

        if (id == R.id.nav_home) {
            this.toInicio(true);
        } else if (id == R.id.nav_perfil) {
            this.toPerfil();
        } else if (id == R.id.nav_membro) {
            this.toMembresia();
        } else if (id == R.id.nav_palavra) {
            this.toPalavra();
        } /* else if (id == R.id.nav_credencial) {
            this.toCredencial();
        } else if (id == R.id.nav_validacao) {
            this.toValidacao();
        }*/ else if (id == R.id.nav_logout) {
            // faça o logout
            this.doLogout();
        }

        DrawerLayout drawer = findViewById(R.id.drawer_layout);
        drawer.closeDrawer(GravityCompat.START);
        return true;
    }

    public void toInicio(boolean replace)
    {
        Fragment home = new HomeFragment();
        FragmentTransaction ft = getSupportFragmentManager().beginTransaction();
        if(replace)
        {
            ft.replace(R.id.main_content, home, "home-frag").commit();
        }
        else
        {
            ft.add(R.id.main_content, home, "home-frag").commit();
        }
    }

    public void toPerfil()
    {
        Fragment frag = new PerfilFragment();
        FragmentTransaction ft = getSupportFragmentManager().beginTransaction();
        ft.replace(R.id.main_content, frag, "perfil-frag").commit();
    }

    public void toMembresia()
    {
        Fragment frag = new MembresiaFragment();
        FragmentTransaction ft = getSupportFragmentManager().beginTransaction();
        ft.replace(R.id.main_content, frag, "membresia-frag").commit();
    }

    public void toPalavra()
    {
        Fragment frag = new PalavraFragment();
        FragmentTransaction ft = getSupportFragmentManager().beginTransaction();
        ft.replace(R.id.main_content, frag, "palavra-frag").commit();
    }

    public void doLogout()
    {
        this.setUserToken("");
        Intent intent = new Intent(
                SmartChurch.this,Login.class
        );
        startActivity(intent);
        finish();
    }

    @Override
    public void onHomeFragInteraction() {

    }

    @Override
    public void onPerfilFragInteraction() {

    }

    @Override
    public void onMembresiaFragmentInteraction() {

    }

    @Override
    public void onPalavraFragmentInteraction() {

    }
}
