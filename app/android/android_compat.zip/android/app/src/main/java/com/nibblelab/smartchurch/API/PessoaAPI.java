package com.nibblelab.smartchurch.API;

import android.util.Log;

import com.nibblelab.smartchurch.API.requests.PessoaRequests;
import com.nibblelab.smartchurch.API.responses.ApiResponse;
import com.nibblelab.smartchurch.activity.Base;
import com.nibblelab.smartchurch.model.PessoaData;
import com.nibblelab.smartchurch.model.ResponseData;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class PessoaAPI extends BaseAPI {

    public final String TAG = "PessoaAPI";

    public PessoaAPI(final Base b) {
        super(b);
    }

    public void getMe(String id, final ApiResponse r) {
        Call<ResponseData<PessoaData>> call = new PessoaRequests().getService().mine(id, this.getAuthToken());
        call.enqueue(new Callback<ResponseData<PessoaData>>() {
            @Override
            public void onResponse(Call<ResponseData<PessoaData>> call, Response<ResponseData<PessoaData>> response) {
                try {
                    if(response.errorBody() != null) {
                        r.onFail(response.errorBody());
                    }
                    else {
                        ResponseData data = response.body();
                        if(data.getSuccess()) {
                            r.onResponse(data.getDatas());
                        }
                        else {
                            r.onError(data.getMsg());
                        }
                    }
                } catch (Exception e) {

                }
            }

            @Override
            public void onFailure(Call<ResponseData<PessoaData>> call, Throwable t) {
                try {
                    r.onFail(t.getMessage());
                    Log.e(TAG, "Erro :" + t.getMessage());
                } catch (Exception e) {

                }
            }
        });
    }

    public void save(PessoaData data, final ApiResponse r)
    {
        Call<ResponseData<Object>> call = new PessoaRequests().getService().edit(data.getId(), data, this.getAuthToken());
        call.enqueue(new Callback<ResponseData<Object>>() {
            @Override
            public void onResponse(Call<ResponseData<Object>> call, Response<ResponseData<Object>> response) {
                try {
                    if(response.errorBody() != null) {
                        r.onFail(response.errorBody());
                    }
                    else {
                        ResponseData data = response.body();
                        if(data.getSuccess()) {
                            r.onResponse();
                        }
                        else {
                            r.onError(data.getMsg());
                        }
                    }
                } catch (Exception e) {

                }
            }

            @Override
            public void onFailure(Call<ResponseData<Object>> call, Throwable t) {
                try {
                    r.onFail(t.getMessage());
                    Log.e(TAG, "Erro :" + t.getMessage());
                } catch (Exception e) {

                }
            }
        });
    }
}
