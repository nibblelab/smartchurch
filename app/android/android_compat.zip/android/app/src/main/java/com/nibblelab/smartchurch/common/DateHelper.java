package com.nibblelab.smartchurch.common;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

public class DateHelper {

    /**
     * Converte de data no padrão SQL para o padrão de calendário
     *
     * @param date
     * @return
     */
    public static String fromDBDateToHumanDate(String date)
    {
        if(date == null || date.length() == 0) {
            return "";
        }

        try {
            Date dt = new SimpleDateFormat("yyyy-MM-dd").parse(date);
            DateFormat df = new SimpleDateFormat("dd/MM/yyyy");
            return df.format(dt);
        } catch (ParseException e) {
            e.printStackTrace();
        }

        return "";
    }

    /**
     * Converte data do padrão de calendário para o SQL
     *
     * @param date
     * @return
     */
    public static String fromHumamDateToDBDate(String date)
    {
        if(date == null || date.length() == 0) {
            return "";
        }

        try {
            Date dt = new SimpleDateFormat("dd/MM/yyyy").parse(date);
            DateFormat df = new SimpleDateFormat("yyyy-MM-dd");
            return df.format(dt);
        } catch (ParseException e) {
            e.printStackTrace();
        }

        return "";
    }

    /**
     * Converte de data e hora no padrão SQL para o padrão de calendário
     *
     * @param time
     * @return
     */
    public static String fromDBTimeToHumanTime(String time)
    {
        if(time == null || time.length() == 0) {
            return "";
        }

        try {
            Date dt = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").parse(time);
            DateFormat df = new SimpleDateFormat("dd/MM/yyyy HH:mm:ss");
            return df.format(dt);
        } catch (ParseException e) {
            e.printStackTrace();
        }

        return "";
    }

    /**
     * Converte data e hora do padrão de calendário para o SQL
     *
     * @param time
     * @return
     */
    public static String fromHumanTimeToDBTime(String time)
    {
        if(time == null || time.length() == 0) {
            return "";
        }

        try {
            Date dt = new SimpleDateFormat("dd/MM/yyyy HH:mm:ss").parse(time);
            DateFormat df = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
            return df.format(dt);
        } catch (ParseException e) {
            e.printStackTrace();
        }

        return "";
    }

    /**
     * Converte de data e hora no padrão SQL para objeto Date
     *
     * @param time
     * @return
     */
    public static Date fromDBTimeToDate(String time)
    {
        if(time == null || time.length() == 0) {
            return null;
        }

        try {
            Date dt = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").parse(time);
            return dt;
        } catch (ParseException e) {
            e.printStackTrace();
        }

        return null;
    }
}
